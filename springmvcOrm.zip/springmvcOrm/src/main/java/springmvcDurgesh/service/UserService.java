package springmvcDurgesh.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springmvcDurgesh.dao.UserDao;
import springmvcDurgesh.model.User;
@Service
public class UserService {
	

	    @Autowired
	    private UserDao userDao;

	    public Long createUser(User user) {
	        return userDao.createUser(user);
	    }
	}
