package springmvcDurgesh.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long userId;

    @Column(name = "username")
    private String emailAlam;

    
    @Column(name = "nameAlam")
    private String nameAlam
    ;
    @Column(name = "password")
    private String passwordAlam;

    // Getters and setters


	public String getEmailAlam() {
		return emailAlam;
	}
	public void setEmailAlam(String emailAlam) {
		this.emailAlam = emailAlam;
	}
	public String getNameAlam() {
		return nameAlam;
	}
	public void setNameAlam(String nameAlam) {
		this.nameAlam = nameAlam;
	}
	public String getPasswordAlam() {
		return passwordAlam;
	}
	public void setPasswordAlam(String passwordAlam) {
		this.passwordAlam = passwordAlam;
	}
	@Override
	public String toString() {
		return "User [emailAlam=" + emailAlam + ", nameAlam=" + nameAlam + ", passwordAlam=" + passwordAlam + "]";
	}
	
	
}
